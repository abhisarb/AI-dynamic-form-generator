import mongoose, { Document, Schema } from 'mongoose';
import { nanoid } from 'nanoid';

// Form field types
export interface IFormField {
    id: string;
    label: string;
    type: 'text' | 'email' | 'number' | 'textarea' | 'select' | 'radio' | 'checkbox' | 'file' | 'date' | 'tel' | 'url';
    placeholder?: string;
    required?: boolean;
    options?: string[]; // For select, radio, checkbox
    validation?: {
        min?: number;
        max?: number;
        pattern?: string;
        minLength?: number;
        maxLength?: number;
    };
}

export interface IFormSchema {
    title: string;
    description?: string;
    fields: IFormField[];
}

// Metadata for context retrieval
export interface IFormMetadata {
    purpose: string; // e.g., "job application", "survey", "medical form"
    fieldTypes: string[]; // e.g., ["text", "email", "file"]
    fieldNames: string[]; // e.g., ["name", "email", "resume"]
    hasFileUpload: boolean;
    fieldCount: number;
    tags: string[]; // Keywords extracted from prompt
}

export interface IForm extends Document {
    userId: mongoose.Types.ObjectId;
    title: string;
    description?: string;
    formSchema: IFormSchema;
    metadata: IFormMetadata;
    shareableId: string;
    pineconeId: string; // ID in Pinecone vector database
    createdAt: Date;
    updatedAt: Date;
}

const formFieldSchema = new Schema<IFormField>(
    {
        id: { type: String, required: true },
        label: { type: String, required: true },
        type: {
            type: String,
            required: true,
            enum: ['text', 'email', 'number', 'textarea', 'select', 'radio', 'checkbox', 'file', 'date', 'tel', 'url']
        },
        placeholder: String,
        required: { type: Boolean, default: false },
        options: [String],
        validation: {
            min: Number,
            max: Number,
            pattern: String,
            minLength: Number,
            maxLength: Number,
        },
    },
    { _id: false }
);

const formSchemaDefinition = new Schema<IFormSchema>(
    {
        title: { type: String, required: true },
        description: String,
        fields: [formFieldSchema],
    },
    { _id: false }
);

const formMetadataSchema = new Schema<IFormMetadata>(
    {
        purpose: { type: String, required: true },
        fieldTypes: [String],
        fieldNames: [String],
        hasFileUpload: { type: Boolean, default: false },
        fieldCount: { type: Number, required: true },
        tags: [String],
    },
    { _id: false }
);

const formSchema = new Schema<IForm>(
    {
        userId: {
            type: Schema.Types.ObjectId,
            ref: 'User',
            required: true,
            index: true,
        },
        title: {
            type: String,
            required: true,
        },
        description: String,
        formSchema: {
            type: formSchemaDefinition,
            required: true,
        },
        metadata: {
            type: formMetadataSchema,
            required: true,
        },
        shareableId: {
            type: String,
            unique: true,
            default: () => nanoid(10),
            index: true,
        },
        pineconeId: {
            type: String,
            required: true,
            unique: true,
        },
    },
    {
        timestamps: true,
    }
);

// Indexes for efficient querying
formSchema.index({ userId: 1, createdAt: -1 });
formSchema.index({ 'metadata.purpose': 1 });
formSchema.index({ 'metadata.tags': 1 });

export const Form = mongoose.model<IForm>('Form', formSchema);
