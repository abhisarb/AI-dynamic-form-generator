import { GoogleGenerativeAI } from '@google/generative-ai';
import { config } from '../config/config';
import { IFormSchema, IFormMetadata } from '../models/Form';

let genAI: GoogleGenerativeAI | null = null;

/**
 * Initialize Google Gemini AI
 */
export const initGemini = (): GoogleGenerativeAI => {
    if (genAI) {
        return genAI;
    }

    genAI = new GoogleGenerativeAI(config.geminiApiKey);
    console.log('✅ Google Gemini AI initialized');
    return genAI;
};

/**
 * Generate embedding for text using Gemini
 */
export const generateEmbedding = async (text: string): Promise<number[]> => {
    try {
        const ai = initGemini();
        const model = ai.getGenerativeModel({ model: 'text-embedding-004' });

        const result = await model.embedContent(text);
        const embedding = result.embedding.values;

        console.log(`✅ Generated embedding (dimension: ${embedding.length})`);
        return embedding;
    } catch (error) {
        console.error('❌ Failed to generate embedding:', error);
        throw error;
    }
};

/**
 * Extract metadata from form schema
 */
export const extractFormMetadata = (
    schema: IFormSchema,
    prompt: string
): IFormMetadata => {
    const fieldTypes = schema.fields.map((f) => f.type);
    const fieldNames = schema.fields.map((f) => f.label.toLowerCase());
    const hasFileUpload = fieldTypes.includes('file');
    const fieldCount = schema.fields.length;

    // Extract tags/keywords from prompt and schema
    const tags = extractKeywords(prompt + ' ' + schema.title + ' ' + (schema.description || ''));

    // Infer purpose from prompt and schema
    const purpose = inferPurpose(prompt, schema);

    return {
        purpose,
        fieldTypes: [...new Set(fieldTypes)], // Unique field types
        fieldNames,
        hasFileUpload,
        fieldCount,
        tags,
    };
};

/**
 * Extract keywords from text
 */
const extractKeywords = (text: string): string[] => {
    // Remove common words and extract meaningful keywords
    const commonWords = new Set([
        'a', 'an', 'the', 'is', 'are', 'was', 'were', 'be', 'been', 'being',
        'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'should',
        'could', 'may', 'might', 'must', 'can', 'i', 'you', 'he', 'she', 'it',
        'we', 'they', 'them', 'their', 'this', 'that', 'these', 'those',
        'with', 'for', 'from', 'to', 'of', 'in', 'on', 'at', 'by', 'and', 'or',
        'but', 'not', 'need', 'want', 'create', 'make', 'form', 'please'
    ]);

    const words = text
        .toLowerCase()
        .replace(/[^\w\s]/g, ' ')
        .split(/\s+/)
        .filter((word) => word.length > 2 && !commonWords.has(word));

    return [...new Set(words)].slice(0, 10); // Top 10 unique keywords
};

/**
 * Infer form purpose from prompt and schema
 */
const inferPurpose = (prompt: string, schema: IFormSchema): string => {
    const text = (prompt + ' ' + schema.title).toLowerCase();

    // Common form categories
    const categories = [
        { keywords: ['job', 'application', 'resume', 'career', 'employment', 'hiring', 'internship'], purpose: 'job application' },
        { keywords: ['survey', 'feedback', 'opinion', 'questionnaire', 'poll'], purpose: 'survey' },
        { keywords: ['contact', 'inquiry', 'message', 'reach'], purpose: 'contact form' },
        { keywords: ['registration', 'signup', 'sign up', 'register', 'account'], purpose: 'registration' },
        { keywords: ['order', 'purchase', 'buy', 'checkout', 'payment'], purpose: 'order form' },
        { keywords: ['medical', 'health', 'patient', 'doctor', 'clinic', 'hospital'], purpose: 'medical form' },
        { keywords: ['event', 'rsvp', 'attendance', 'conference', 'workshop'], purpose: 'event registration' },
        { keywords: ['admission', 'enrollment', 'college', 'university', 'school'], purpose: 'admission form' },
        { keywords: ['booking', 'reservation', 'appointment', 'schedule'], purpose: 'booking form' },
    ];

    for (const category of categories) {
        if (category.keywords.some((keyword) => text.includes(keyword))) {
            return category.purpose;
        }
    }

    return 'general form';
};

/**
 * Build context-aware prompt for form generation
 */
export const buildContextPrompt = (
    userPrompt: string,
    relevantForms: Array<{
        title: string;
        purpose: string;
        fieldTypes: string[];
        fieldNames: string[];
        hasFileUpload: boolean;
    }>
): string => {
    let contextSection = '';

    if (relevantForms.length > 0) {
        contextSection = `\n\nHere is relevant context from the user's past forms for reference:\n`;
        relevantForms.forEach((form, index) => {
            contextSection += `\n${index + 1}. "${form.title}" (${form.purpose})`;
            contextSection += `\n   - Fields: ${form.fieldNames.slice(0, 5).join(', ')}${form.fieldNames.length > 5 ? '...' : ''}`;
            contextSection += `\n   - Field types used: ${[...new Set(form.fieldTypes)].join(', ')}`;
            if (form.hasFileUpload) {
                contextSection += `\n   - Includes file upload`;
            }
        });
        contextSection += '\n\nUse this context to inform field selection, ordering, and validation rules.\n';
    }

    const prompt = `You are an intelligent form schema generator. Your task is to convert natural language descriptions into structured JSON form schemas.
${contextSection}
User request: "${userPrompt}"

Generate a JSON form schema with the following structure:
{
  "title": "Form Title",
  "description": "Brief description of the form",
  "fields": [
    {
      "id": "unique_field_id",
      "label": "Field Label",
      "type": "text|email|number|textarea|select|radio|checkbox|file|date|tel|url",
      "placeholder": "Optional placeholder text",
      "required": true|false,
      "options": ["option1", "option2"], // Only for select, radio, checkbox
      "validation": {
        "min": 0, // For number fields
        "max": 100, // For number fields
        "minLength": 3, // For text fields
        "maxLength": 100, // For text fields
        "pattern": "regex pattern" // For advanced validation
      }
    }
  ]
}

Important guidelines:
1. Use appropriate field types (text, email, number, textarea, select, radio, checkbox, file, date, tel, url)
2. Add validation rules where appropriate (required, min/max, patterns)
3. For file uploads, use type "file"
4. Include helpful placeholder text
5. Make field IDs lowercase with underscores (e.g., "full_name", "email_address")
6. Order fields logically (e.g., name before email, basic info before detailed questions)
7. If the user mentions specific fields, include them
8. If context suggests certain patterns (like resume upload for job forms), follow them

Return ONLY the JSON schema, no additional text or explanation.`;

    return prompt;
};

/**
 * Generate form schema from user prompt with context
 */
export const generateFormSchema = async (
    userPrompt: string,
    relevantForms: Array<{
        title: string;
        purpose: string;
        fieldTypes: string[];
        fieldNames: string[];
        hasFileUpload: boolean;
    }> = []
): Promise<IFormSchema> => {
    try {
        const ai = initGemini();
        const model = ai.getGenerativeModel({ model: 'gemini-1.5-flash' });

        const prompt = buildContextPrompt(userPrompt, relevantForms);

        console.log('🤖 Generating form schema with Gemini...');
        const result = await model.generateContent(prompt);
        const response = result.response.text();

        // Extract JSON from response
        const schema = parseFormSchema(response);

        console.log(`✅ Generated form schema with ${schema.fields.length} fields`);
        return schema;
    } catch (error) {
        console.error('❌ Failed to generate form schema:', error);
        throw error;
    }
};

/**
 * Parse and validate form schema from LLM response
 */
export const parseFormSchema = (response: string): IFormSchema => {
    try {
        // Extract JSON from markdown code blocks if present
        let jsonStr = response.trim();

        // Remove markdown code blocks
        if (jsonStr.startsWith('```')) {
            jsonStr = jsonStr.replace(/```json\n?/g, '').replace(/```\n?/g, '');
        }

        // Find JSON object
        const jsonMatch = jsonStr.match(/\{[\s\S]*\}/);
        if (!jsonMatch) {
            throw new Error('No JSON object found in response');
        }

        const schema = JSON.parse(jsonMatch[0]);

        // Validate schema structure
        if (!schema.title || !Array.isArray(schema.fields)) {
            throw new Error('Invalid schema structure: missing title or fields');
        }

        // Validate each field
        schema.fields.forEach((field: any, index: number) => {
            if (!field.id || !field.label || !field.type) {
                throw new Error(`Invalid field at index ${index}: missing id, label, or type`);
            }
        });

        return schema as IFormSchema;
    } catch (error) {
        console.error('❌ Failed to parse form schema:', error);
        console.error('Response:', response);
        throw new Error('Failed to parse form schema from AI response');
    }
};
