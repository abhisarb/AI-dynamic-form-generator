import { Pinecone } from '@pinecone-database/pinecone';
import { config } from '../config/config';

let pineconeClient: Pinecone | null = null;

/**
 * Initialize Pinecone client
 */
export const initPinecone = async (): Promise<Pinecone> => {
    if (pineconeClient) {
        return pineconeClient;
    }

    try {
        pineconeClient = new Pinecone({
            apiKey: config.pineconeApiKey,
        });

        console.log('✅ Pinecone client initialized');
        return pineconeClient;
    } catch (error) {
        console.error('❌ Failed to initialize Pinecone:', error);
        throw error;
    }
};

/**
 * Get Pinecone index
 */
export const getPineconeIndex = async () => {
    const client = await initPinecone();
    return client.index(config.pineconeIndexName);
};

/**
 * Store form embedding in Pinecone
 */
export const storeFormEmbedding = async (
    formId: string,
    embedding: number[],
    metadata: {
        userId: string;
        title: string;
        purpose: string;
        fieldTypes: string[];
        fieldNames: string[];
        hasFileUpload: boolean;
        fieldCount: number;
        tags: string[];
    }
) => {
    try {
        const index = await getPineconeIndex();

        await index.upsert([
            {
                id: formId,
                values: embedding,
                metadata: {
                    ...metadata,
                    // Convert arrays to strings for Pinecone metadata
                    fieldTypes: metadata.fieldTypes.join(','),
                    fieldNames: metadata.fieldNames.join(','),
                    tags: metadata.tags.join(','),
                },
            },
        ]);

        console.log(`✅ Stored embedding for form ${formId} in Pinecone`);
    } catch (error) {
        console.error('❌ Failed to store embedding in Pinecone:', error);
        throw error;
    }
};

/**
 * Query Pinecone for similar forms
 */
export const querySimilarForms = async (
    queryEmbedding: number[],
    userId: string,
    topK: number = 5
): Promise<Array<{
    id: string;
    score: number;
    metadata: any;
}>> => {
    try {
        const index = await getPineconeIndex();

        const queryResponse = await index.query({
            vector: queryEmbedding,
            topK,
            filter: {
                userId: { $eq: userId },
            },
            includeMetadata: true,
        });

        const results = queryResponse.matches.map((match) => ({
            id: match.id,
            score: match.score || 0,
            metadata: {
                ...match.metadata,
                // Convert comma-separated strings back to arrays
                fieldTypes: match.metadata?.fieldTypes
                    ? (match.metadata.fieldTypes as string).split(',')
                    : [],
                fieldNames: match.metadata?.fieldNames
                    ? (match.metadata.fieldNames as string).split(',')
                    : [],
                tags: match.metadata?.tags
                    ? (match.metadata.tags as string).split(',')
                    : [],
            },
        }));

        console.log(`✅ Found ${results.length} similar forms in Pinecone`);
        return results;
    } catch (error) {
        console.error('❌ Failed to query Pinecone:', error);
        throw error;
    }
};

/**
 * Delete form embedding from Pinecone
 */
export const deleteFormEmbedding = async (formId: string) => {
    try {
        const index = await getPineconeIndex();
        await index.deleteOne(formId);
        console.log(`✅ Deleted embedding for form ${formId} from Pinecone`);
    } catch (error) {
        console.error('❌ Failed to delete embedding from Pinecone:', error);
        throw error;
    }
};

/**
 * Check if Pinecone index exists and create if needed
 */
export const ensurePineconeIndex = async () => {
    try {
        const client = await initPinecone();
        const indexList = await client.listIndexes();

        const indexExists = indexList.indexes?.some(
            (index) => index.name === config.pineconeIndexName
        );

        if (!indexExists) {
            console.log(`Creating Pinecone index: ${config.pineconeIndexName}`);
            await client.createIndex({
                name: config.pineconeIndexName,
                dimension: 768, // Gemini text-embedding-004 dimension
                metric: 'cosine',
                spec: {
                    serverless: {
                        cloud: 'aws',
                        region: 'us-east-1',
                    },
                },
            });
            console.log('✅ Pinecone index created');

            // Wait for index to be ready
            await new Promise(resolve => setTimeout(resolve, 5000));
        } else {
            console.log('✅ Pinecone index already exists');
        }
    } catch (error) {
        console.error('❌ Failed to ensure Pinecone index:', error);
        throw error;
    }
};
