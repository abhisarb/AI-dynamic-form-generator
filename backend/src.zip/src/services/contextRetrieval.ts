import { generateEmbedding } from './geminiService';
import { querySimilarForms } from './pineconeService';
import { Form } from '../models/Form';

/**
 * Context retrieval service for intelligent form history
 */

interface RelevantFormContext {
    title: string;
    purpose: string;
    fieldTypes: string[];
    fieldNames: string[];
    hasFileUpload: boolean;
}

/**
 * Retrieve relevant forms from user's history using semantic search
 */
export const retrieveRelevantForms = async (
    userId: string,
    userPrompt: string,
    topK: number = 5
): Promise<RelevantFormContext[]> => {
    try {
        console.log(`🔍 Retrieving relevant forms for user ${userId}...`);

        // Check if user has any forms
        const userFormCount = await Form.countDocuments({ userId });

        if (userFormCount === 0) {
            console.log('ℹ️  User has no previous forms (cold start)');
            return [];
        }

        console.log(`📊 User has ${userFormCount} total forms`);

        // Generate embedding for user's prompt
        const promptEmbedding = await generateEmbedding(userPrompt);

        // Query Pinecone for similar forms
        const similarForms = await querySimilarForms(
            promptEmbedding,
            userId,
            Math.min(topK, userFormCount)
        );

        if (similarForms.length === 0) {
            console.log('ℹ️  No similar forms found');
            return [];
        }

        // Filter by similarity threshold (0.5 = 50% similar)
        const relevantForms = similarForms.filter((form) => form.score >= 0.5);

        console.log(
            `✅ Found ${relevantForms.length} relevant forms (scores: ${relevantForms
                .map((f) => f.score.toFixed(2))
                .join(', ')})`
        );

        // Convert to context format
        const context: RelevantFormContext[] = relevantForms.map((form) => ({
            title: form.metadata.title as string,
            purpose: form.metadata.purpose as string,
            fieldTypes: form.metadata.fieldTypes as string[],
            fieldNames: form.metadata.fieldNames as string[],
            hasFileUpload: form.metadata.hasFileUpload as boolean,
        }));

        return context;
    } catch (error) {
        console.error('❌ Failed to retrieve relevant forms:', error);
        // Don't throw - return empty context on error
        return [];
    }
};

/**
 * Build metadata text for embedding generation
 */
export const buildMetadataText = (
    title: string,
    description: string | undefined,
    purpose: string,
    fieldNames: string[],
    tags: string[]
): string => {
    const parts = [
        `Title: ${title}`,
        description ? `Description: ${description}` : '',
        `Purpose: ${purpose}`,
        `Fields: ${fieldNames.join(', ')}`,
        `Tags: ${tags.join(', ')}`,
    ];

    return parts.filter(Boolean).join('\n');
};

/**
 * Calculate token estimate for context
 */
export const estimateContextTokens = (
    relevantForms: RelevantFormContext[]
): number => {
    // Rough estimate: ~4 characters per token
    let totalChars = 0;

    relevantForms.forEach((form) => {
        totalChars += form.title.length;
        totalChars += form.purpose.length;
        totalChars += form.fieldNames.join(', ').length;
        totalChars += 100; // Overhead for formatting
    });

    return Math.ceil(totalChars / 4);
};

/**
 * Limit context to stay within token budget
 */
export const limitContextByTokens = (
    relevantForms: RelevantFormContext[],
    maxTokens: number = 2000
): RelevantFormContext[] => {
    const limited: RelevantFormContext[] = [];
    let currentTokens = 0;

    for (const form of relevantForms) {
        const formTokens = estimateContextTokens([form]);

        if (currentTokens + formTokens <= maxTokens) {
            limited.push(form);
            currentTokens += formTokens;
        } else {
            break;
        }
    }

    if (limited.length < relevantForms.length) {
        console.log(
            `⚠️  Limited context from ${relevantForms.length} to ${limited.length} forms to stay within token budget`
        );
    }

    return limited;
};

/**
 * Cache for recent retrievals (simple in-memory cache)
 */
interface CacheEntry {
    context: RelevantFormContext[];
    timestamp: number;
}

const retrievalCache = new Map<string, CacheEntry>();
const CACHE_TTL = 5 * 60 * 1000; // 5 minutes

/**
 * Get cached retrieval result if available
 */
export const getCachedRetrieval = (
    userId: string,
    userPrompt: string
): RelevantFormContext[] | null => {
    const cacheKey = `${userId}:${userPrompt}`;
    const cached = retrievalCache.get(cacheKey);

    if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
        console.log('✅ Using cached retrieval result');
        return cached.context;
    }

    // Clean up expired entries
    if (cached) {
        retrievalCache.delete(cacheKey);
    }

    return null;
};

/**
 * Cache retrieval result
 */
export const cacheRetrieval = (
    userId: string,
    userPrompt: string,
    context: RelevantFormContext[]
): void => {
    const cacheKey = `${userId}:${userPrompt}`;
    retrievalCache.set(cacheKey, {
        context,
        timestamp: Date.now(),
    });

    // Limit cache size
    if (retrievalCache.size > 100) {
        const oldestKey = retrievalCache.keys().next().value;
        if (oldestKey) {
            retrievalCache.delete(oldestKey);
        }
    }
};

/**
 * Main function: Retrieve relevant forms with caching and token limiting
 */
export const getRelevantFormsForGeneration = async (
    userId: string,
    userPrompt: string,
    options: {
        topK?: number;
        maxTokens?: number;
        useCache?: boolean;
    } = {}
): Promise<RelevantFormContext[]> => {
    const { topK = 5, maxTokens = 2000, useCache = true } = options;

    // Check cache first
    if (useCache) {
        const cached = getCachedRetrieval(userId, userPrompt);
        if (cached) {
            return cached;
        }
    }

    // Retrieve relevant forms
    let relevantForms = await retrieveRelevantForms(userId, userPrompt, topK);

    // Limit by token budget
    relevantForms = limitContextByTokens(relevantForms, maxTokens);

    // Cache result
    if (useCache) {
        cacheRetrieval(userId, userPrompt, relevantForms);
    }

    return relevantForms;
};
