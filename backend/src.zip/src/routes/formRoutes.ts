import express, { Response } from 'express';
import { body, validationResult } from 'express-validator';
import { nanoid } from 'nanoid';
import { authenticate, AuthRequest } from '../middleware/auth';
import { Form } from '../models/Form';
import {
    generateFormSchema,
    extractFormMetadata,
    generateEmbedding,
} from '../services/geminiService';
import { getRelevantFormsForGeneration, buildMetadataText } from '../services/contextRetrieval';
import { storeFormEmbedding, deleteFormEmbedding } from '../services/pineconeService';

const router = express.Router();

/**
 * POST /api/forms/generate
 * Generate a new form from natural language prompt
 */
router.post(
    '/generate',
    authenticate,
    [
        body('prompt')
            .notEmpty()
            .withMessage('Prompt is required')
            .isLength({ min: 10, max: 1000 })
            .withMessage('Prompt must be between 10 and 1000 characters'),
    ],
    async (req: AuthRequest, res: Response) => {
        try {
            // Validate input
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                return res.status(400).json({
                    success: false,
                    errors: errors.array(),
                });
            }

            const { prompt } = req.body;
            const userId = req.userId!;

            console.log(`📝 Generating form for user ${userId}: "${prompt}"`);

            // Step 1: Retrieve relevant forms from user's history
            const relevantForms = await getRelevantFormsForGeneration(userId, prompt, {
                topK: 5,
                maxTokens: 2000,
                useCache: true,
            });

            console.log(`📚 Using ${relevantForms.length} relevant forms as context`);

            // Step 2: Generate form schema with context
            const schema = await generateFormSchema(prompt, relevantForms);

            // Step 3: Extract metadata for future retrieval
            const metadata = extractFormMetadata(schema, prompt);

            // Step 4: Generate embedding for the form
            const metadataText = buildMetadataText(
                schema.title,
                schema.description,
                metadata.purpose,
                metadata.fieldNames,
                metadata.tags
            );
            const embedding = await generateEmbedding(metadataText);

            // Step 5: Create unique IDs
            const shareableId = nanoid(10);
            const pineconeId = `form_${userId}_${Date.now()}_${nanoid(8)}`;

            // Step 6: Store in Pinecone
            await storeFormEmbedding(pineconeId, embedding, {
                userId,
                title: schema.title,
                purpose: metadata.purpose,
                fieldTypes: metadata.fieldTypes,
                fieldNames: metadata.fieldNames,
                hasFileUpload: metadata.hasFileUpload,
                fieldCount: metadata.fieldCount,
                tags: metadata.tags,
            });

            // Step 7: Save form to MongoDB
            const form = new Form({
                userId,
                title: schema.title,
                description: schema.description,
                formSchema: schema,
                metadata,
                shareableId,
                pineconeId,
            });

            await form.save();

            console.log(`✅ Form created successfully: ${form._id}`);

            res.status(201).json({
                success: true,
                message: 'Form generated successfully',
                data: {
                    form: {
                        id: form._id,
                        title: form.title,
                        description: form.description,
                        schema: form.formSchema,
                        shareableId: form.shareableId,
                        createdAt: form.createdAt,
                    },
                    context: {
                        usedRelevantForms: relevantForms.length > 0,
                        relevantFormsCount: relevantForms.length,
                    },
                },
            });
        } catch (error) {
            console.error('Form generation error:', error);
            res.status(500).json({
                success: false,
                message: 'Failed to generate form',
                error: error instanceof Error ? error.message : 'Unknown error',
            });
        }
    }
);

/**
 * GET /api/forms
 * Get all forms for authenticated user
 */
router.get('/forms', authenticate, async (req: AuthRequest, res: Response) => {
    try {
        const userId = req.userId!;

        const forms = await Form.find({ userId })
            .sort({ createdAt: -1 })
            .select('-pineconeId -__v');

        res.json({
            success: true,
            data: {
                forms,
                count: forms.length,
            },
        });
    } catch (error) {
        console.error('Get forms error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch forms',
        });
    }
});

/**
 * GET /api/forms/:id
 * Get specific form by ID
 */
router.get('/forms/:id', authenticate, async (req: AuthRequest, res: Response) => {
    try {
        const { id } = req.params;
        const userId = req.userId!;

        const form = await Form.findOne({ _id: id, userId }).select('-pineconeId -__v');

        if (!form) {
            return res.status(404).json({
                success: false,
                message: 'Form not found',
            });
        }

        res.json({
            success: true,
            data: { form },
        });
    } catch (error) {
        console.error('Get form error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch form',
        });
    }
});

/**
 * DELETE /api/forms/:id
 * Delete form
 */
router.delete('/forms/:id', authenticate, async (req: AuthRequest, res: Response) => {
    try {
        const { id } = req.params;
        const userId = req.userId!;

        const form = await Form.findOne({ _id: id, userId });

        if (!form) {
            return res.status(404).json({
                success: false,
                message: 'Form not found',
            });
        }

        // Delete from Pinecone
        await deleteFormEmbedding(form.pineconeId);

        // Delete from MongoDB
        await form.deleteOne();

        res.json({
            success: true,
            message: 'Form deleted successfully',
        });
    } catch (error) {
        console.error('Delete form error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to delete form',
        });
    }
});

export default router;
